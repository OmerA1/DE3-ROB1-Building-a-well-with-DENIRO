from trial import calculate_brick_locations

brick_locations = calculate_brick_locations()

print(brick_locations[0,0])
